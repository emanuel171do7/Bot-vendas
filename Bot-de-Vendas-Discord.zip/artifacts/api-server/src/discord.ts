import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  Client,
  EmbedBuilder,
  GatewayIntentBits,
  PermissionFlagsBits,
  REST,
  Routes,
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  type Interaction,
} from "discord.js";
import { logger } from "./lib/logger";
import {
  addStock, createOrder, createOrderById, fulfillOrder, getProductById,
  listPendingOrders, listPanelsForProduct, listProducts, markDelivered,
  removePanel, releaseReservation, reportPayment, savePanel, setStockQuantity,
  upsertProduct,
} from "./lib/store";

const token = process.env.DISCORD_BOT_TOKEN;
const pixKey = process.env.PIX_RANDOM_KEY;
const clientId = process.env.DISCORD_CLIENT_ID;
const guildId = process.env.DISCORD_GUILD_ID;

if (!token) throw new Error("DISCORD_BOT_TOKEN não configurado.");
if (!pixKey) throw new Error("PIX_RANDOM_KEY não configurado.");
if (!clientId) throw new Error("DISCORD_CLIENT_ID não configurado.");
const discordToken: string = token;
const applicationClientId: string = clientId;

const commands = [
  new SlashCommandBuilder().setName("produtos").setDescription("Lista os produtos disponíveis"),
  new SlashCommandBuilder().setName("comprar").setDescription("Inicia uma compra")
    .addStringOption(o => o.setName("produto").setDescription("Nome exato do produto").setRequired(true)),
  new SlashCommandBuilder().setName("painel-enviar").setDescription("Envia a loja interativa no canal atual (admin)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild.toString())
    .addStringOption(o => o.setName("produto").setDescription("Nome exato do produto").setRequired(true)),
  new SlashCommandBuilder().setName("avisar-regras").setDescription("Envia o aviso de regras do teste (admin)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild.toString()),
  new SlashCommandBuilder().setName("duvidas").setDescription("Envia as dúvidas frequentes"),
  new SlashCommandBuilder().setName("produto-configurar").setDescription("Cria ou atualiza um produto (admin)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild.toString())
    .addStringOption(o => o.setName("nome").setDescription("Nome do produto").setRequired(true))
    .addIntegerOption(o => o.setName("preco_centavos").setDescription("Preço em centavos (ex.: 1990 = R$ 19,90)").setRequired(true).setMinValue(0))
    .addStringOption(o => o.setName("descricao").setDescription("Descrição do produto").setRequired(true))
    .addStringOption(o => o.setName("imagem_url").setDescription("URL direta opcional de imagem ou GIF (https://.../banner.gif)").setRequired(false)),
  new SlashCommandBuilder().setName("estoque-adicionar").setDescription("Adiciona um item ao estoque (admin)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild.toString())
    .addStringOption(o => o.setName("produto").setDescription("Nome exato do produto").setRequired(true))
    .addStringOption(o => o.setName("item").setDescription("Conteúdo entregue ao comprador").setRequired(true)),
  new SlashCommandBuilder().setName("estoque").setDescription("Define a quantidade disponível de um produto (admin)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild.toString())
    .addStringOption(o => o.setName("produto").setDescription("Produto cadastrado").setRequired(true).setAutocomplete(true))
    .addIntegerOption(o => o.setName("quantidade").setDescription("Quantidade disponível (zero também é permitido)").setRequired(true).setMinValue(0)),
  new SlashCommandBuilder().setName("pagamentos-pendentes").setDescription("Lista pagamentos aguardando confirmação (admin)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild.toString()),
  new SlashCommandBuilder().setName("pagamento-aprovar").setDescription("Confirma pagamento e entrega o item (admin)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild.toString())
    .addIntegerOption(o => o.setName("pedido").setDescription("Número do pedido").setRequired(true).setMinValue(1)),
].map(command => command.toJSON());

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

function money(cents: number): string {
  return (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function isAdmin(interaction: ChatInputCommandInteraction): boolean {
  return Boolean(interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild));
}

function shopEmbed(product: {
  name: string;
  description: string;
  price_cents: number;
  available_stock: number;
  image_url: string | null;
}): EmbedBuilder {
  const specifications = product.description
    .split(/\r?\n/)
    .map(specification => specification.trim())
    .filter(Boolean)
    .map(specification => specification.startsWith("✅") ? specification : `✅ ${specification}`)
    .join("\n");

  const embed = new EmbedBuilder()
    .setTitle(product.name)
    .setColor(0x8a2be2)
    .setDescription(
      `${specifications || "✅ Produto digital de alta qualidade"}\n\n` +
      `---\n\n` +
      "```text\n" +
      `PREÇO À VISTA : ${money(product.price_cents)}\n` +
      "```",
    )
    .addFields({
      name: "Disponibilidade",
      value: `**Restam apenas ${product.available_stock} unidades**`,
      inline: true,
    })
    .setFooter({ text: "Entrega automática • Pagamento via Pix" });
  if (product.image_url) embed.setImage(product.image_url);
  return embed;
}

function productsTableEmbed(products: ReturnType<typeof listProducts>): EmbedBuilder {
  const table = [
    "| Produto | Valor à vista | Estoque |",
    "|---|---:|---:|",
    ...products.map(product =>
      `| ${product.name.replace(/\|/g, "\\|")} | ${money(product.price_cents)} | ${product.available_stock} |`,
    ),
  ].join("\n");

  return new EmbedBuilder()
    .setTitle("Produtos disponíveis")
    .setColor(0xff0000)
    .setDescription(table)
    .addFields(
      products.map(product => ({
        name: product.name,
        value: product.description,
        inline: false,
      })),
    )
    .setFooter({ text: "Tabela atualizada em tempo real" });
}

function buyButton(productId: number, availableStock: number): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`buy:${productId}`)
      .setLabel(availableStock > 0 ? "✅ Compra" : "🔔 Sem estoque no momento...")
      .setEmoji(availableStock > 0 ? "🛒" : "🔔")
      .setStyle(availableStock > 0 ? ButtonStyle.Success : ButtonStyle.Secondary)
      .setDisabled(availableStock === 0),
  );
}

function rulesEmbed(): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0xff0000)
    .setTitle("TESTAR LIVE")
    .setDescription(
      "**TROCAS SOMENTE ATÉ 10 MINUTOS**\n\n" +
      "*Vídeo mostrando que a info não vinculou no ifood*\n" +
      "*Estar dentro do prazo de troca (10min)*\n" +
      "*JÁ faça envio das provas caso esteja die.*\n\n" +
      "---\n\n" +
      "**Atenção aos retornos**\n\n" +
      "✔ *cartão adicionado/salvo =* **Info Live**\n" +
      "❌ *cartão inválido =* **Info die**\n" +
      "❕ *Caso contrario, não terá troca!*",
    );
}

function faqEmbed(): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0xff0000)
    .setDescription(
      "❓ **DÚVIDAS FREQUENTES**\n\n" +
      "**O QUE É LIVE E DIE?**\n" +
      "• **Live:** Quando o cartão está válido, foi debitado em algum lugar ou passou no teste.\n" +
      "• **Die:** O oposto de live; ocorre quando o cartão não tem aprovação.\n\n" +
      "---\n\n" +
      "**O QUE É CHK?**\n" +
      "• Chk é o teste realizado pelos vendedores para validar e confirmar se os cartões estão realmente **live**.\n\n" +
      "---\n\n" +
      "**O QUE É VBV?**\n" +
      "• **VBV** (*Verified by Visa*) é uma camada de segurança que confirma a identidade do comprador na transação.\n" +
      "• *Nota:* Cair no VBV não significa que o cartão é ruim, apenas que a loja exige essa verificação extra.\n\n" +
      "---\n\n" +
      "**LOJAS CONHECIDAS x LOJAS MEDIANAS**\n" +
      "• 🔒 **Grandes Redes:** Possuem segurança reforçada, tornando as aprovações mais difíceis.\n" +
      "• 🎯 **Lojas Medianas/Menos Famosas:** Têm barreiras de segurança menores, aumentando as chances de sucesso.",
    );
}

function gpayButton(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setLabel("Teste Gpay").setStyle(ButtonStyle.Link).setURL("https://pay.google.com/"),
  );
}

async function sendPaymentInstructions(interaction: ChatInputCommandInteraction, productName: string, userId: string, username: string): Promise<void> {
  const order = createOrder(productName, userId, username);
  const button = new ButtonBuilder().setCustomId(`verify-payment:${order.id}`).setLabel("Já paguei — confirmar pagamento").setStyle(ButtonStyle.Primary);
  const embed = new EmbedBuilder()
    .setTitle(`Pagamento do pedido #${order.id}`)
    .setColor(0x8a2be2)
    .setDescription(`Produto: **${order.product_name}**\nValor à vista: **${money(order.price_cents)}**`)
    .addFields(
      { name: "Pague via Pix", value: `Chave aleatória:\n\`${pixKey}\`` },
      { name: "Depois de pagar", value: "Clique no botão abaixo. Após a conferência, seu item será enviado automaticamente por DM." },
    );
  await interaction.reply({ embeds: [embed], components: [new ActionRowBuilder<ButtonBuilder>().addComponents(button)], ephemeral: true });
}

async function handleCommand(interaction: ChatInputCommandInteraction): Promise<void> {
  try {
    if (interaction.commandName === "produtos") {
      const products = listProducts();
      if (!products.length) {
        await interaction.reply("Ainda não há produtos cadastrados.");
        return;
      }
      await interaction.reply({ embeds: [productsTableEmbed(products)] });
      return;
    }

    if (interaction.commandName === "comprar") {
      const productName = interaction.options.getString("produto", true);
      await sendPaymentInstructions(interaction, productName, interaction.user.id, interaction.user.tag);
      return;
    }

    if (interaction.commandName === "duvidas") {
      if (!interaction.channel || !("send" in interaction.channel)) throw new Error("Este comando precisa ser usado em um canal de texto.");
      await interaction.channel.send({ embeds: [faqEmbed()] });
      await interaction.reply({ content: "Embed de dúvidas frequentes enviada neste canal.", ephemeral: true });
      return;
    }

    if (!isAdmin(interaction)) {
      await interaction.reply({ content: "Você precisa da permissão Gerenciar Servidor para usar este comando.", ephemeral: true });
      return;
    }

    if (interaction.commandName === "produto-configurar") {
      const product = upsertProduct(
        interaction.options.getString("nome", true),
        interaction.options.getString("descricao", true),
        interaction.options.getInteger("preco_centavos", true),
        interaction.options.getString("imagem_url") ?? undefined,
      );
      await interaction.reply(`Produto **${product.name}** configurado por ${money(product.price_cents)}${product.image_url ? " com banner." : "."}`);
    } else if (interaction.commandName === "estoque-adicionar") {
      const itemId = addStock(interaction.options.getString("produto", true), interaction.options.getString("item", true));
      await interaction.reply(`Item adicionado ao estoque com ID interno ${itemId}.`);
    } else if (interaction.commandName === "estoque") {
      const productName = interaction.options.getString("produto", true);
      const quantity = interaction.options.getInteger("quantidade", true);
      const product = setStockQuantity(productName, quantity);
      const panels = listPanelsForProduct(product.id);
      let updatedPanels = 0;
      for (const panel of panels) {
        try {
          const channel = await client.channels.fetch(panel.channel_id);
          if (!channel?.isTextBased() || !("messages" in channel)) continue;
          const message = await channel.messages.fetch(panel.message_id);
          await message.edit({
            embeds: [shopEmbed(product)],
            components: [buyButton(product.id, product.available_stock)],
          });
          updatedPanels += 1;
        } catch {
          removePanel(panel.message_id);
        }
      }
      await interaction.reply({
        content: `✅ Estoque do produto ${product.name} alterado para ${product.available_stock} unidades com sucesso!`,
        ephemeral: true,
      });
    } else if (interaction.commandName === "pagamentos-pendentes") {
      const orders = listPendingOrders();
      await interaction.reply(orders.length ? orders.map(o => `#${o.id} — ${o.product_name} — ${o.discord_username} — ${money(o.price_cents)}`).join("\n") : "Nenhum pagamento aguardando confirmação.");
    } else if (interaction.commandName === "pagamento-aprovar") {
      const orderId = interaction.options.getInteger("pedido", true);
      const { order, contents } = fulfillOrder(orderId);
      try {
        const user = await client.users.fetch(order.discord_user_id);
        await user.send(`Pagamento confirmado!\n\nSeu produto **${order.product_name}** (pedido #${order.id}):\n\n${contents}`);
        markDelivered(orderId);
        await interaction.reply(`Pedido #${orderId} confirmado e entregue por DM para ${order.discord_username}.`);
      } catch (error) {
        releaseReservation(orderId);
        throw new Error(`não foi possível enviar a DM (${error instanceof Error ? error.message : "erro desconhecido"}). O item foi devolvido ao estoque.`);
      }
    } else if (interaction.commandName === "painel-enviar") {
      const productName = interaction.options.getString("produto", true);
      const product = listProducts().find(item => item.name.toLowerCase() === productName.toLowerCase());
      if (!product) throw new Error("Produto não encontrado.");
      if (!interaction.channel || !("send" in interaction.channel)) throw new Error("Este comando precisa ser usado em um canal de texto.");
      const panelMessage = await interaction.channel.send({
        embeds: [shopEmbed(product)],
        components: [buyButton(product.id, product.available_stock)],
      });
      savePanel(product.id, interaction.channel.id, panelMessage.id);
      await interaction.reply({ content: `Painel de **${product.name}** enviado neste canal.`, ephemeral: true });
    } else if (interaction.commandName === "avisar-regras") {
      if (!interaction.channel || !("send" in interaction.channel)) throw new Error("Este comando precisa ser usado em um canal de texto.");
      await interaction.channel.send({ embeds: [rulesEmbed()], components: [gpayButton()] });
      await interaction.reply({ content: "Aviso de regras enviado neste canal.", ephemeral: true });
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : "Erro inesperado.";
    logger.error({ err: error }, "Discord command failed");
    if (interaction.replied || interaction.deferred) await interaction.followUp({ content: message, ephemeral: true });
    else await interaction.reply({ content: message, ephemeral: true });
  }
}

async function handleInteraction(interaction: Interaction): Promise<void> {
  if (interaction.isAutocomplete()) {
    const focused = interaction.options.getFocused().toLowerCase();
    await interaction.respond(
      listProducts()
        .filter(product => product.name.toLowerCase().includes(focused))
        .slice(0, 25)
        .map(product => ({ name: `${product.name} (${product.available_stock} disponíveis)`, value: product.name })),
    );
    return;
  }
  if (interaction.isChatInputCommand()) await handleCommand(interaction);
  if (interaction.isButton() && interaction.customId.startsWith("buy:")) {
    try {
      const productId = Number(interaction.customId.split(":")[1]);
      const product = getProductById(productId);
      if (!product) throw new Error("Produto não encontrado.");
      if (!interaction.guild) throw new Error("A compra precisa ser iniciada dentro de um servidor.");
      const order = createOrderById(product.id, interaction.user.id, interaction.user.tag);
      const button = new ButtonBuilder().setCustomId(`verify-payment:${order.id}`).setLabel("Já paguei — confirmar pagamento").setStyle(ButtonStyle.Primary);
      const embed = new EmbedBuilder()
        .setTitle(`Carrinho • Pedido #${order.id}`)
        .setColor(0x8a2be2)
        .setDescription(`Olá, <@${interaction.user.id}>!\n\nProduto: **${order.product_name}**\nValor à vista: **${money(order.price_cents)}**`)
        .addFields(
          { name: "Pague via Pix", value: `Chave aleatória:\n\`${pixKey}\`` },
          { name: "Depois de pagar", value: "Clique no botão abaixo. Após a conferência, seu item será enviado automaticamente por DM." },
        );
      const safeUsername = interaction.user.username.toLowerCase().replace(/[^a-z0-9-]/g, "-").slice(0, 18) || "cliente";
      const ticket = await interaction.guild.channels.create({
        name: `carrinho-${safeUsername}-${order.id}`,
        type: ChannelType.GuildText,
        topic: `Carrinho do pedido #${order.id} • ${order.product_name}`,
        permissionOverwrites: [
          { id: interaction.guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
          { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
          ...(client.user ? [{
            id: client.user.id,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory,
              PermissionFlagsBits.ManageChannels,
            ],
          }] : []),
        ],
      });
      await ticket.send({
        content: `🛒 Carrinho de <@${interaction.user.id}>`,
        embeds: [embed],
        components: [new ActionRowBuilder<ButtonBuilder>().addComponents(button)],
      });
      await interaction.reply({ content: `🛒 Seu carrinho foi aberto: ${ticket}`, ephemeral: true });
    } catch (error) {
      await interaction.reply({ content: error instanceof Error ? error.message : "Não foi possível iniciar a compra.", ephemeral: true });
    }
  }
  if (interaction.isButton() && interaction.customId.startsWith("verify-payment:")) {
    const orderId = Number(interaction.customId.split(":")[1]);
    try {
      const order = reportPayment(orderId, interaction.user.id);
      await interaction.reply({ content: `Solicitação registrada para o pedido #${order.id}. Um administrador fará a conferência e liberará sua entrega por DM.`, ephemeral: true });
      const admins = interaction.guild?.members.cache.filter(member => member.permissions.has(PermissionFlagsBits.ManageGuild));
      if (admins) for (const [, admin] of admins) await admin.send(`Pagamento aguardando confirmação: pedido #${order.id}, ${order.product_name}, ${order.discord_username}. Use /pagamento-aprovar pedido:${order.id}.`).catch(() => undefined);
    } catch (error) {
      await interaction.reply({ content: error instanceof Error ? error.message : "Não foi possível registrar o pagamento.", ephemeral: true });
    }
  }
}

export async function startDiscordBot(): Promise<void> {
  const rest = new REST({ version: "10" }).setToken(discordToken);
  if (guildId) await rest.put(Routes.applicationGuildCommands(applicationClientId, guildId), { body: commands });
  else await rest.put(Routes.applicationCommands(applicationClientId), { body: commands });
  client.on("interactionCreate", interaction => void handleInteraction(interaction));
  client.once("clientReady", ready => logger.info({ tag: ready.user.tag }, "Discord sales bot online"));
  await client.login(discordToken);
}