import Database from "better-sqlite3";
import { mkdirSync } from "node:fs";
import path from "node:path";

const dataDir = path.resolve(process.cwd(), "data");
mkdirSync(dataDir, { recursive: true });

const db = new Database(path.join(dataDir, "discord-store.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE COLLATE NOCASE,
    description TEXT NOT NULL,
    price_cents INTEGER NOT NULL CHECK (price_cents >= 0),
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS stock_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL REFERENCES products(id),
    contents TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'reserved', 'delivered')),
    order_id INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL REFERENCES products(id),
    discord_user_id TEXT NOT NULL,
    discord_username TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'awaiting_payment'
      CHECK (status IN ('awaiting_payment', 'payment_reported', 'fulfilled', 'cancelled')),
    stock_item_id INTEGER REFERENCES stock_items(id),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fulfilled_at TEXT
  );
  CREATE TABLE IF NOT EXISTS store_panels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL REFERENCES products(id),
    channel_id TEXT NOT NULL,
    message_id TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);
try {
  db.exec("ALTER TABLE products ADD COLUMN image_url TEXT");
} catch {
  // Column already exists on databases created by this version.
}

export type Product = {
  id: number;
  name: string;
  description: string;
  price_cents: number;
  available_stock: number;
  image_url: string | null;
};

export type Order = {
  id: number;
  product_name: string;
  price_cents: number;
  discord_user_id: string;
  discord_username: string;
  status: string;
  created_at: string;
};

const productRow = db.prepare(`
  SELECT p.id, p.name, p.description, p.price_cents, p.image_url,
    (SELECT COUNT(*) FROM stock_items s WHERE s.product_id = p.id AND s.status = 'available') AS available_stock
  FROM products p WHERE p.active = 1 AND p.name = ?
`);

export function listProducts(): Product[] {
  return db.prepare(`
    SELECT p.id, p.name, p.description, p.price_cents, p.image_url,
      (SELECT COUNT(*) FROM stock_items s WHERE s.product_id = p.id AND s.status = 'available') AS available_stock
    FROM products p WHERE p.active = 1 ORDER BY p.name
  `).all() as Product[];
}

export function upsertProduct(name: string, description: string, priceCents: number, imageUrl?: string): Product {
  const normalizedImageUrl = imageUrl?.trim() || null;
  if (normalizedImageUrl) {
    let parsedUrl: URL;
    try {
      parsedUrl = new URL(normalizedImageUrl);
    } catch {
      throw new Error("A URL do banner precisa ser válida e direta (https://...).");
    }
    if (parsedUrl.protocol !== "http:" && parsedUrl.protocol !== "https:") {
      throw new Error("A URL do banner precisa começar com http:// ou https://.");
    }
  }
  db.prepare(`
    INSERT INTO products (name, description, price_cents, image_url) VALUES (?, ?, ?, ?)
    ON CONFLICT(name) DO UPDATE SET description = excluded.description, price_cents = excluded.price_cents,
      image_url = excluded.image_url, active = 1
  `).run(name, description, priceCents, normalizedImageUrl);
  return productRow.get(name) as Product;
}

export function addStock(productName: string, contents: string): number {
  const product = productRow.get(productName) as Product | undefined;
  if (!product) throw new Error("Produto não encontrado. Configure-o primeiro com /produto-configurar.");
  const result = db.prepare("INSERT INTO stock_items (product_id, contents) VALUES (?, ?)").run(product.id, contents);
  return Number(result.lastInsertRowid);
}

export function setStockQuantity(productName: string, quantity: number): Product {
  if (!Number.isInteger(quantity) || quantity < 0) throw new Error("A quantidade deve ser um número inteiro igual ou maior que zero.");
  const product = productRow.get(productName) as Product | undefined;
  if (!product) throw new Error("Produto não encontrado.");

  const transaction = db.transaction(() => {
    const availableItems = db.prepare(`
      SELECT id FROM stock_items
      WHERE product_id = ? AND status = 'available'
      ORDER BY id
    `).all(product.id) as { id: number }[];

    if (quantity < availableItems.length) {
      const idsToRemove = availableItems.slice(quantity);
      const remove = db.prepare("DELETE FROM stock_items WHERE id = ? AND status = 'available'");
      for (const item of idsToRemove) remove.run(item.id);
    } else if (quantity > availableItems.length) {
      const add = db.prepare("INSERT INTO stock_items (product_id, contents) VALUES (?, ?)");
      for (let i = availableItems.length; i < quantity; i += 1) {
        add.run(product.id, "[Conteúdo do item ainda não preenchido]");
      }
    }
  });
  transaction();
  return productRow.get(productName) as Product;
}

export function createOrder(productName: string, userId: string, username: string): Order {
  const product = productRow.get(productName) as Product | undefined;
  if (!product) throw new Error("Produto não encontrado.");
  if (product.available_stock < 1) throw new Error("Este produto está sem estoque.");
  const result = db.prepare(`
    INSERT INTO orders (product_id, discord_user_id, discord_username)
    VALUES (?, ?, ?)
  `).run(product.id, userId, username);
  return db.prepare(`
    SELECT o.id, p.name AS product_name, p.price_cents, o.discord_user_id, o.discord_username, o.status, o.created_at
    FROM orders o JOIN products p ON p.id = o.product_id WHERE o.id = ?
  `).get(result.lastInsertRowid) as Order;
}

export function createOrderById(productId: number, userId: string, username: string): Order {
  const product = db.prepare("SELECT name FROM products WHERE id = ? AND active = 1").get(productId) as { name: string } | undefined;
  if (!product) throw new Error("Produto não encontrado.");
  return createOrder(product.name, userId, username);
}

export function getProductById(productId: number): Product | undefined {
  return db.prepare(`
    SELECT p.id, p.name, p.description, p.price_cents, p.image_url,
      (SELECT COUNT(*) FROM stock_items s WHERE s.product_id = p.id AND s.status = 'available') AS available_stock
    FROM products p WHERE p.active = 1 AND p.id = ?
  `).get(productId) as Product | undefined;
}

export function reportPayment(orderId: number, userId: string): Order {
  const order = db.prepare(`
    SELECT o.id, p.name AS product_name, p.price_cents, o.discord_user_id, o.discord_username, o.status, o.created_at
    FROM orders o JOIN products p ON p.id = o.product_id WHERE o.id = ? AND o.discord_user_id = ?
  `).get(orderId, userId) as Order | undefined;
  if (!order) throw new Error("Pedido não encontrado ou não pertence a você.");
  if (order.status !== "awaiting_payment") throw new Error("Este pedido já foi enviado para verificação.");
  db.prepare("UPDATE orders SET status = 'payment_reported' WHERE id = ?").run(orderId);
  return { ...order, status: "payment_reported" };
}

export function fulfillOrder(orderId: number): { order: Order; contents: string } {
  const transaction = db.transaction(() => {
    const order = db.prepare(`
      SELECT o.id, p.name AS product_name, p.price_cents, o.discord_user_id, o.discord_username, o.status, o.created_at
      FROM orders o JOIN products p ON p.id = o.product_id
      WHERE o.id = ? AND o.status = 'payment_reported'
    `).get(orderId) as Order | undefined;
    if (!order) throw new Error("Pedido não encontrado ou ainda não foi marcado como pago.");
    const item = db.prepare(`
      SELECT id, contents FROM stock_items
      WHERE product_id = (SELECT product_id FROM orders WHERE id = ?) AND status = 'available'
      ORDER BY id LIMIT 1
    `).get(orderId) as { id: number; contents: string } | undefined;
    if (!item) throw new Error("Não há item disponível para este produto.");
    db.prepare("UPDATE stock_items SET status = 'reserved', order_id = ? WHERE id = ?").run(orderId, item.id);
    db.prepare("UPDATE orders SET stock_item_id = ? WHERE id = ?").run(item.id, orderId);
    return { order, contents: item.contents };
  });
  return transaction() as { order: Order; contents: string };
}

export function markDelivered(orderId: number): void {
  db.prepare("UPDATE orders SET status = 'fulfilled', fulfilled_at = CURRENT_TIMESTAMP WHERE id = ?").run(orderId);
  db.prepare("UPDATE stock_items SET status = 'delivered' WHERE order_id = ?").run(orderId);
}

export function releaseReservation(orderId: number): void {
  db.prepare("UPDATE stock_items SET status = 'available', order_id = NULL WHERE order_id = ? AND status = 'reserved'").run(orderId);
  db.prepare("UPDATE orders SET stock_item_id = NULL WHERE id = ?").run(orderId);
}

export function listPendingOrders(): Order[] {
  return db.prepare(`
    SELECT o.id, p.name AS product_name, p.price_cents, o.discord_user_id, o.discord_username, o.status, o.created_at
    FROM orders o JOIN products p ON p.id = o.product_id
    WHERE o.status = 'payment_reported' ORDER BY o.id
  `).all() as Order[];
}

export function savePanel(productId: number, channelId: string, messageId: string): void {
  db.prepare(`
    INSERT INTO store_panels (product_id, channel_id, message_id) VALUES (?, ?, ?)
    ON CONFLICT(message_id) DO UPDATE SET product_id = excluded.product_id, channel_id = excluded.channel_id
  `).run(productId, channelId, messageId);
}

export function listPanelsForProduct(productId: number): { channel_id: string; message_id: string }[] {
  return db.prepare("SELECT channel_id, message_id FROM store_panels WHERE product_id = ?").all(productId) as { channel_id: string; message_id: string }[];
}

export function removePanel(messageId: string): void {
  db.prepare("DELETE FROM store_panels WHERE message_id = ?").run(messageId);
}